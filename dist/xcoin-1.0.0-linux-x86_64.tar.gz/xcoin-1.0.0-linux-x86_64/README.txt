X Coin (XFER) 1.0.0 — Linux x86_64 (private)
Nifty Raven (@NFTRVN on X)

bin/xcoin-qt   desktop GUI (required for 1.0)
bin/xcoind     node / lottery producer
bin/xcoin-cli  RPC

Run:  ./bin/xcoin-qt
Regtest: ./bin/xcoin-qt -regtest

Build line:
  ./autogen.sh
  ./configure --with-gui=qt5 --disable-bench --disable-tests --with-incompatible-bdb
  make -j$(nproc)
